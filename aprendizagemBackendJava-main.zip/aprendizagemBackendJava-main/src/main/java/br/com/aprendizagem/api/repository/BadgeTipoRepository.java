package br.com.aprendizagem.api.repository;

import br.com.aprendizagem.api.entity.BadgeTipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BadgeTipoRepository extends JpaRepository<BadgeTipo, Integer> {
}
