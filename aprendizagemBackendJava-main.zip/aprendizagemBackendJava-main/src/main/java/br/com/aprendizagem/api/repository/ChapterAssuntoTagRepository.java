package br.com.aprendizagem.api.repository;

import br.com.aprendizagem.api.entity.ChapterAssuntoTag;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChapterAssuntoTagRepository extends JpaRepository<ChapterAssuntoTag, Integer> {
}
