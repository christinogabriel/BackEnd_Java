package br.com.aprendizagem.api.repository;

import br.com.aprendizagem.api.entity.AtividadeTipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AtividadeTipoRepository extends JpaRepository<AtividadeTipo, Integer> {
}
