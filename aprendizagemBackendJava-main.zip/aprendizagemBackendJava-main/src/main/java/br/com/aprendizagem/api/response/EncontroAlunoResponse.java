package br.com.aprendizagem.api.response;

public class EncontroAlunoResponse {
}
