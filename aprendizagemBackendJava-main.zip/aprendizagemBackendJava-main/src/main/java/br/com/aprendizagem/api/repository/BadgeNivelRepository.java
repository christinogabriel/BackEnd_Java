package br.com.aprendizagem.api.repository;

import br.com.aprendizagem.api.entity.BadgeNivel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BadgeNivelRepository extends JpaRepository<BadgeNivel, Integer> {
}
